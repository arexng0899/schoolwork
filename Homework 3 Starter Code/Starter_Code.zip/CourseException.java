public class CourseException extends Exception {
    public CourseException(String s) {
        // write your code here
    }
}
